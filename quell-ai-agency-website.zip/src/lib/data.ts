export interface NavItem {
  label: string;
  href: string;
}

export interface ServiceItem {
  id: string;
  index: string;
  title: string;
  iconName: "workflow" | "layers" | "bot";
  description: string;
  bullets: [string, string, string];
  focusValue: "AI Automation" | "AI Integration" | "AI Agent Development";
}

export interface ProcessStep {
  number: string;
  title: string;
  subtitle: string;
  description: string;
  deliverables: string[];
}

export interface CaseStudyItem {
  id: string;
  client: string;
  industry: string;
  image: string;
  metric: string;
  metricLabel: string;
  title: string;
  description: string;
  timeline: string;
  stack: string[];
  outcomes: string[];
}

export interface StatItem {
  value: string;
  label: string;
  sublabel: string;
}

export interface TestimonialItem {
  quote: string;
  name: string;
  role: string;
  company: string;
  impact: string;
}

export const NAV_LINKS: NavItem[] = [
  { label: "Projects", href: "/work" },
  { label: "Services", href: "/services" },
  { label: "About", href: "/about" },
  { label: "Blog", href: "/blog" },
  { label: "Contact", href: "/contact" },
];

export const HERO_CAPABILITIES = [
  "AI AUTOMATION",
  "AI INTEGRATION",
  "AI AGENT DEVELOPMENT",
] as const;

export const SERVICES: ServiceItem[] = [
  {
    id: "ai-automation",
    index: "01",
    title: "AI Automation",
    iconName: "workflow",
    description:
      "Replace brittle manual operations with deterministic, auditable AI pipelines engineered for zero-touch throughput.",
    bullets: [
      "End-to-end document, invoice & ERP reconciliation",
      "Real-time exception triage with human-in-the-loop controls",
      "Sub-second webhook orchestration & full telemetry",
    ],
    focusValue: "AI Automation",
  },
  {
    id: "ai-integration",
    index: "02",
    title: "AI Integration",
    iconName: "layers",
    description:
      "Embed frontier models directly into your proprietary stack—securely grounded in your CRM, warehouse, and internal APIs.",
    bullets: [
      "Enterprise RAG architectures with role-based permissions",
      "Native connectors for Salesforce, NetSuite, Slack & Postgres",
      "SOC-2 aligned guardrails, latency caching & model routing",
    ],
    focusValue: "AI Integration",
  },
  {
    id: "ai-agent-development",
    index: "03",
    title: "AI Agent Development",
    iconName: "bot",
    description:
      "Deploy specialized autonomous agents capable of multi-step reasoning, tool execution, and continuous learning at scale.",
    bullets: [
      "Multi-agent orchestration with strict schema verification",
      "Autonomous qualification, support & research specialists",
      "Continuous evaluation harnesses & drift monitoring",
    ],
    focusValue: "AI Agent Development",
  },
];

export const PROCESS_STEPS: ProcessStep[] = [
  {
    number: "01",
    title: "Discover",
    subtitle: "Operational Audit & ROI Blueprint",
    description:
      "We shadow your core operators, map high-friction bottlenecks across your stack, and quantify the exact time and margin unlocked before writing a single line of code.",
    deliverables: ["Workflow Telemetry Map", "ROI Projection", "Security Scope"],
  },
  {
    number: "02",
    title: "Design",
    subtitle: "Deterministic System Architecture",
    description:
      "Every pipeline is spec'd for production reliability—defining model routing, fallback logic, evaluation datasets, and strict human-approval boundaries.",
    deliverables: ["System Blueprint", "Eval Benchmark Suite", "Data Contracts"],
  },
  {
    number: "03",
    title: "Build",
    subtitle: "Rapid Engineering & Shadow Deployment",
    description:
      "Our engineers ship hardened production code in focused two-week sprints, running parallel shadow tests against live operational volume to validate accuracy.",
    deliverables: ["Production Agents", "API Integrations", "Observability Hub"],
  },
  {
    number: "04",
    title: "Scale",
    subtitle: "Continuous Optimization & Ownership",
    description:
      "Once live, we monitor latency, token efficiency, and edge-case drift—iterating on prompt & model upgrades as your business volume compounds.",
    deliverables: ["24/7 Drift Alerts", "Model Upgrades", "Team Enablement"],
  },
];

export const CASE_STUDIES: CaseStudyItem[] = [
  {
    id: "freight-automation",
    client: "Nordline Freight Group",
    industry: "Global Logistics",
    image: "/images/case-study-1.png",
    metric: "62%",
    metricLabel: "less manual work",
    title: "Autonomous Freight & Invoice Reconciliation",
    description:
      "Eliminated manual customs auditing and invoice matching across 14 regional hubs with a multi-stage vision and ERP automation pipeline.",
    timeline: "4 weeks to production",
    stack: ["Vision Extraction", "NetSuite ERP", "Deterministic Rules Engine"],
    outcomes: [
      "62% reduction in manual back-office processing hours",
      "99.6% line-item verification accuracy across 80k monthly docs",
      "4.2-hour average turnaround compressed to 90 seconds",
    ],
  },
  {
    id: "fintech-rag",
    client: "Vectra Capital Systems",
    industry: "Enterprise Fintech",
    image: "/images/case-study-2.png",
    metric: "4.8x",
    metricLabel: "faster response",
    title: "Unified Underwriting & Analyst Copilot",
    description:
      "Connected live CRM records, filings, and proprietary credit memos into a zero-hallucination RAG layer embedded directly in analyst workflows.",
    timeline: "5 weeks to production",
    stack: ["Hybrid Vector Search", "Citations Layer", "Salesforce & Snowflake"],
    outcomes: [
      "4.8x acceleration in pre-investment diligence synthesis",
      "100% source-attributed outputs with inline document links",
      "Adopted daily by 140+ analysts within 14 days of rollout",
    ],
  },
  {
    id: "autonomous-support-agents",
    client: "Aetheria Cloud",
    industry: "B2B SaaS",
    image: "/images/case-study-3.png",
    metric: "$1.4M",
    metricLabel: "annual savings",
    title: "Multi-Agent Revenue & Support Orchestration",
    description:
      "Engineered autonomous Tier-1/Tier-2 resolution and inbound qualification agents with direct tool execution across billing and telemetry APIs.",
    timeline: "3 weeks to production",
    stack: ["Multi-Agent Graph", "Stripe & Zendesk APIs", "Live Eval Harness"],
    outcomes: [
      "$1.4M net annualized operational savings verified in Q1",
      "78% autonomous resolution rate with 4.9/5 CSAT score",
      "Zero headcount expansion required across 3x customer growth",
    ],
  },
];

export const STATS: StatItem[] = [
  {
    value: "100+",
    label: "Businesses Automated",
    sublabel: "Across fintech, logistics & SaaS",
  },
  {
    value: "40k+",
    label: "Hours Reclaimed",
    sublabel: "Saved every single month",
  },
  {
    value: "99.4%",
    label: "Pipeline Reliability",
    sublabel: "Production SLA across live agents",
  },
  {
    value: "3.2 wks",
    label: "Avg. Time to Live",
    sublabel: "From architecture kickoff to ROI",
  },
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    quote:
      "Quell didn't sell us an AI demo—they rebuilt our entire dispatch reconciliation engine in four weeks. Manual touchpoints dropped by more than half overnight.",
    name: "Henrik Lindqvist",
    role: "VP of Operations",
    company: "Nordline Freight",
    impact: "62% faster ops",
  },
  {
    quote:
      "Mitha and her engineering team operate with rare rigor. Every agent they shipped came with evaluation benchmarks, strict guardrails, and measurable margin impact.",
    name: "Claire Beaumont",
    role: "Chief Technology Officer",
    company: "Vectra Capital",
    impact: "4.8x diligence speed",
  },
  {
    quote:
      "Within 30 days of deploying Quell's autonomous qualification and triage agents, our response times dropped to seconds and we avoided hiring six full-time coordinators.",
    name: "Devon Takahashi",
    role: "Co-founder & COO",
    company: "Aetheria Cloud",
    impact: "$1.4M saved / yr",
  },
];

export const TIME_SLOTS = [
  "09:30 AM",
  "10:30 AM",
  "11:30 AM",
  "02:00 PM",
  "03:30 PM",
  "04:30 PM",
] as const;

export const SERVICE_FOCUS_OPTIONS = [
  "AI Automation",
  "AI Integration",
  "AI Agent Development",
  "Full Systems Audit",
] as const;
