import { pgTable, serial, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";

export const consultations = pgTable("consultations", {
  id: serial("id").primaryKey(),
  referenceCode: text("reference_code").notNull().unique(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  company: text("company").notNull(),
  serviceFocus: text("service_focus").notNull(),
  preferredDate: text("preferred_date").notNull(),
  preferredTime: text("preferred_time").notNull(),
  notes: text("notes"),
  status: text("status").notNull().default("confirmed"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const waitlistSubscribers = pgTable(
  "waitlist_subscribers",
  {
    id: serial("id").primaryKey(),
    email: text("email").notNull(),
    section: text("section").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("waitlist_email_section_idx").on(table.email, table.section),
  ]
);

export type Consultation = typeof consultations.$inferSelect;
export type NewConsultation = typeof consultations.$inferInsert;
export type WaitlistSubscriber = typeof waitlistSubscribers.$inferSelect;
