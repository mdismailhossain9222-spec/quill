import type { Metadata } from "next";
import { ComingSoonPage } from "@/components/sections/ComingSoonPage";

export const metadata: Metadata = {
  title: "About",
  description:
    "Meet the engineers and founders behind Quell's deterministic AI automation agency.",
};

export default function AboutPage() {
  return (
    <ComingSoonPage
      section="about"
      eyebrow="About Quell"
      headline="Engineering Clarity at Scale"
      description="Built by systems engineers and applied AI researchers obsessed with turning fragile manual operations into resilient autonomous infrastructure."
      previewNote="Our studio story, leadership profiles, and engineering principles manifesto are launching shortly. Join the list to be notified when the page goes live."
    />
  );
}
