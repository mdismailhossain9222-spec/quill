import type { Metadata } from "next";
import { ComingSoonPage } from "@/components/sections/ComingSoonPage";

export const metadata: Metadata = {
  title: "Work",
  description:
    "Selected case studies and measured automation ROI engineered by Quell.",
};

export default function WorkPage() {
  return (
    <ComingSoonPage
      section="work"
      eyebrow="Selected Work"
      headline="Measured, Not Promised"
      description="Deep-dive technical teardowns, latency benchmarks, and audited ROI reports across 100+ production AI automation deployments."
      previewNote="Our complete archive of client architecture case studies is being curated for publication. Subscribe for first look access or book a call to review relevant deployments privately."
    />
  );
}
