import type { Metadata } from "next";
import { ComingSoonPage } from "@/components/sections/ComingSoonPage";

export const metadata: Metadata = {
  title: "Blog",
  description:
    "Research notes, agent evaluation frameworks, and production AI architecture dispatches from Quell.",
};

export default function BlogPage() {
  return (
    <ComingSoonPage
      section="blog"
      eyebrow="Journal & Research"
      headline="Dispatches From Production AI"
      description="Field notes on multi-agent orchestration, deterministic evaluation harnesses, enterprise RAG security, and real-world automation economics."
      previewNote="Our inaugural series of technical essays from Mitha and the Quell engineering team is in final editorial review. Drop your email to receive issue #01."
    />
  );
}
