import { db } from "@/db";
import { consultations } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import crypto from "crypto";

export const dynamic = "force-dynamic";

const ALLOWED_SERVICES = [
  "AI Automation",
  "AI Integration",
  "AI Agent Development",
  "Full Systems Audit",
] as const;

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export async function GET() {
  try {
    const booked = await db
      .select({
        preferredDate: consultations.preferredDate,
        preferredTime: consultations.preferredTime,
      })
      .from(consultations)
      .where(eq(consultations.status, "confirmed"))
      .orderBy(desc(consultations.createdAt))
      .limit(100);

    return Response.json({
      bookedSlots: booked.map((row) => ({
        date: row.preferredDate,
        time: row.preferredTime,
      })),
    });
  } catch (error) {
    console.error("Failed to fetch consultation slots:", error);
    return Response.json(
      { error: "Unable to load live availability." },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;

    const name = typeof body.name === "string" ? body.name.trim() : "";
    const email =
      typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const company = typeof body.company === "string" ? body.company.trim() : "";
    const serviceFocus =
      typeof body.serviceFocus === "string" ? body.serviceFocus.trim() : "";
    const preferredDate =
      typeof body.preferredDate === "string" ? body.preferredDate.trim() : "";
    const preferredTime =
      typeof body.preferredTime === "string" ? body.preferredTime.trim() : "";
    const notes =
      typeof body.notes === "string" ? body.notes.trim().slice(0, 1000) : "";

    if (name.length < 2) {
      return Response.json(
        { error: "Please enter your full name." },
        { status: 400 }
      );
    }

    if (!isValidEmail(email)) {
      return Response.json(
        { error: "Please enter a valid work email address." },
        { status: 400 }
      );
    }

    if (company.length < 2) {
      return Response.json(
        { error: "Please enter your company or team name." },
        { status: 400 }
      );
    }

    if (
      !ALLOWED_SERVICES.includes(
        serviceFocus as (typeof ALLOWED_SERVICES)[number]
      )
    ) {
      return Response.json(
        { error: "Please select a valid focus area." },
        { status: 400 }
      );
    }

    if (!preferredDate || !preferredTime) {
      return Response.json(
        { error: "Please select a date and time slot." },
        { status: 400 }
      );
    }

    const existingSlot = await db
      .select({ id: consultations.id })
      .from(consultations)
      .where(
        and(
          eq(consultations.preferredDate, preferredDate),
          eq(consultations.preferredTime, preferredTime),
          eq(consultations.status, "confirmed")
        )
      )
      .limit(1);

    if (existingSlot.length > 0) {
      return Response.json(
        {
          error:
            "That time slot was just reserved. Please pick another available time.",
        },
        { status: 409 }
      );
    }

    const randomHex = crypto.randomBytes(3).toString("hex").toUpperCase();
    const referenceCode = `QLL-${randomHex}`;

    const [created] = await db
      .insert(consultations)
      .values({
        referenceCode,
        name,
        email,
        company,
        serviceFocus,
        preferredDate,
        preferredTime,
        notes: notes || null,
        status: "confirmed",
      })
      .returning({
        id: consultations.id,
        referenceCode: consultations.referenceCode,
        name: consultations.name,
        email: consultations.email,
        company: consultations.company,
        serviceFocus: consultations.serviceFocus,
        preferredDate: consultations.preferredDate,
        preferredTime: consultations.preferredTime,
        createdAt: consultations.createdAt,
      });

    return Response.json(
      {
        message: "Your 15-minute discovery call with Mitha is confirmed.",
        booking: created,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Failed to create consultation booking:", error);
    return Response.json(
      { error: "Unable to complete booking right now. Please try again." },
      { status: 500 }
    );
  }
}
