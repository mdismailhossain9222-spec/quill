import { db } from "@/db";
import { waitlistSubscribers } from "@/db/schema";

export const dynamic = "force-dynamic";

const ALLOWED_SECTIONS = [
  "services",
  "work",
  "about",
  "blog",
  "contact",
] as const;

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const email =
      typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const section =
      typeof body.section === "string" ? body.section.trim().toLowerCase() : "";

    if (!isValidEmail(email)) {
      return Response.json(
        { error: "Please enter a valid email address." },
        { status: 400 }
      );
    }

    if (
      !ALLOWED_SECTIONS.includes(section as (typeof ALLOWED_SECTIONS)[number])
    ) {
      return Response.json(
        { error: "Invalid destination section." },
        { status: 400 }
      );
    }

    const inserted = await db
      .insert(waitlistSubscribers)
      .values({ email, section })
      .onConflictDoNothing({
        target: [waitlistSubscribers.email, waitlistSubscribers.section],
      })
      .returning({ id: waitlistSubscribers.id });

    if (inserted.length === 0) {
      return Response.json(
        {
          alreadySubscribed: true,
          message: "You're already on the priority launch list.",
        },
        { status: 200 }
      );
    }

    return Response.json(
      {
        alreadySubscribed: false,
        message: "You're on the list. We'll notify you as soon as this goes live.",
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Failed to subscribe to waitlist:", error);
    return Response.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 }
    );
  }
}
