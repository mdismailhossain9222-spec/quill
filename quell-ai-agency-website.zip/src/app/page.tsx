import { PageTransition } from "@/components/motion/MotionPrimitives";
import { HeroSection } from "@/components/home/HeroSection";
import { LogoStrip } from "@/components/home/LogoStrip";
import { ServicesSection } from "@/components/home/ServicesSection";
import { ProcessSection } from "@/components/home/ProcessSection";
import { CaseStudiesSection } from "@/components/home/CaseStudiesSection";
import { StatsSection } from "@/components/home/StatsSection";
import { TestimonialsSection } from "@/components/home/TestimonialsSection";
import { FounderCtaSection } from "@/components/home/FounderCtaSection";

export default function HomePage() {
  return (
    <PageTransition>
      <HeroSection />
      <LogoStrip />
      <ServicesSection />
      <ProcessSection />
      <CaseStudiesSection />
      <StatsSection />
      <TestimonialsSection />
      <FounderCtaSection />
    </PageTransition>
  );
}
