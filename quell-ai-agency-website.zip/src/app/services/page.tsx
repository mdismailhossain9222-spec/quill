import type { Metadata } from "next";
import { ComingSoonPage } from "@/components/sections/ComingSoonPage";

export const metadata: Metadata = {
  title: "Services",
  description:
    "Explore Quell's AI Automation, Enterprise AI Integration, and Autonomous Agent Development capabilities.",
};

export default function ServicesPage() {
  return (
    <ComingSoonPage
      section="services"
      eyebrow="Services"
      headline="Precision AI Systems & Capabilities"
      description="Detailed technical specifications, SLA guarantees, and architecture blueprints across AI Automation, AI Integration, and Autonomous Agent Development."
      previewNote="We are finalizing our interactive service blueprints and ROI calculator. Leave your email for early access, or schedule a direct 15-minute call with Mitha today."
    />
  );
}
