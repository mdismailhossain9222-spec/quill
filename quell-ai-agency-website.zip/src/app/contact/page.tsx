import type { Metadata } from "next";
import { ComingSoonPage } from "@/components/sections/ComingSoonPage";

export const metadata: Metadata = {
  title: "Contact",
  description:
    "Connect with Quell for enterprise AI automation, integration, and autonomous agent engineering.",
};

export default function ContactPage() {
  return (
    <ComingSoonPage
      section="contact"
      eyebrow="Contact"
      headline="Start a Focused Conversation"
      description="Whether you are scaling an existing automation footprint or scoping your first autonomous workflow, our founders respond directly."
      previewNote="Our dedicated project intake portal is launching soon. In the meantime, you can book a 15-minute architecture call directly with Mitha below or email hello@quell.ai."
    />
  );
}
