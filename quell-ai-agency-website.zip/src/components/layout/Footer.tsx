"use client";

import Link from "next/link";
import { ArrowUpRight, Hexagon, Mail } from "lucide-react";
import { useBooking } from "@/components/providers/BookingContext";

const COMPANY_LINKS = [
  { label: "Home", href: "/" },
  { label: "Projects", href: "/work" },
  { label: "Services", href: "/services" },
  { label: "About", href: "/about" },
  { label: "Blog", href: "/blog" },
  { label: "Contact", href: "/contact" },
];

const CAPABILITY_LINKS = [
  { label: "AI Automation", focus: "AI Automation" },
  { label: "AI Integration", focus: "AI Integration" },
  { label: "AI Agent Development", focus: "AI Agent Development" },
  { label: "Full Systems Audit", focus: "Full Systems Audit" },
];

export function Footer() {
  const { openBookingModal } = useBooking();

  return (
    <footer className="relative border-t border-white/10 bg-[#09090b]">
      {/* Subtle top emerald center hairline */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-emerald-400/35 to-transparent" />

      <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8 lg:py-20">
        <div className="grid gap-12 lg:grid-cols-12">
          {/* Brand column */}
          <div className="lg:col-span-5">
            <Link href="/" className="inline-flex items-center gap-2.5">
              <span className="relative flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/[0.05] text-emerald-400">
                <Hexagon className="h-5 w-5 stroke-[1.75]" />
                <span className="absolute h-1.5 w-1.5 rounded-full bg-emerald-400" />
              </span>
              <span className="text-lg font-semibold tracking-tight text-white">
                Quell
              </span>
            </Link>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-zinc-400">
              Precision AI automation, enterprise system integration, and
              autonomous agent engineering for high-velocity teams.
            </p>
            <div className="mt-6 flex items-center gap-2.5">
              <a
                href="https://x.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Quell on X"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-zinc-400 transition-all hover:border-emerald-400/40 hover:bg-emerald-400/10 hover:text-emerald-300"
              >
                <svg
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  className="h-3.5 w-3.5 fill-current"
                >
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Quell on LinkedIn"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-zinc-400 transition-all hover:border-emerald-400/40 hover:bg-emerald-400/10 hover:text-emerald-300"
              >
                <svg
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  className="h-4 w-4 fill-current"
                >
                  <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.28 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.75M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z" />
                </svg>
              </a>
              <a
                href="https://github.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Quell on GitHub"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-zinc-400 transition-all hover:border-emerald-400/40 hover:bg-emerald-400/10 hover:text-emerald-300"
              >
                <svg
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  className="h-4 w-4 fill-current"
                >
                  <path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0 1 12 6.844a9.59 9.59 0 0 1 2.504.337c1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.02 10.02 0 0 0 22 12.017C22 6.484 17.522 2 12 2z" />
                </svg>
              </a>
              <a
                href="mailto:hello@quell.ai"
                aria-label="Email Quell"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-zinc-400 transition-all hover:border-emerald-400/40 hover:bg-emerald-400/10 hover:text-emerald-300"
              >
                <Mail className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Navigation */}
          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:col-span-7">
            <div>
              <h3 className="font-mono text-[11px] uppercase tracking-[0.18em] text-zinc-500">
                Navigation
              </h3>
              <ul className="mt-4 space-y-2.5">
                {COMPANY_LINKS.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-sm text-zinc-400 transition-colors hover:text-white"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-mono text-[11px] uppercase tracking-[0.18em] text-zinc-500">
                Capabilities
              </h3>
              <ul className="mt-4 space-y-2.5">
                {CAPABILITY_LINKS.map((item) => (
                  <li key={item.label}>
                    <button
                      type="button"
                      onClick={() => openBookingModal(item.focus)}
                      className="text-left text-sm text-zinc-400 transition-colors hover:text-emerald-300"
                    >
                      {item.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            <div className="col-span-2 sm:col-span-1">
              <h3 className="font-mono text-[11px] uppercase tracking-[0.18em] text-zinc-500">
                Direct
              </h3>
              <div className="mt-4 space-y-3 text-sm text-zinc-400">
                <p>San Francisco · London</p>
                <a
                  href="mailto:hello@quell.ai"
                  className="block text-zinc-300 transition-colors hover:text-emerald-400"
                >
                  hello@quell.ai
                </a>
                <button
                  type="button"
                  onClick={() => openBookingModal("AI Automation")}
                  className="inline-flex items-center gap-1.5 pt-1 text-sm font-medium text-emerald-400 transition-colors hover:text-emerald-300"
                >
                  <span>Book 15-mins call</span>
                  <ArrowUpRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-14 flex flex-col items-start justify-between gap-4 border-t border-white/[0.08] pt-8 text-xs text-zinc-500 sm:flex-row sm:items-center">
          <p>© {new Date().getFullYear()} Quell AI Inc. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <span className="inline-flex items-center gap-2 font-mono text-[11px] text-zinc-400">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
              All automation systems operational
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
