"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, Hexagon, Menu, X } from "lucide-react";
import { NAV_LINKS } from "@/lib/data";
import { useBooking } from "@/components/providers/BookingContext";
import { EDITORIAL_EASE } from "@/components/motion/MotionPrimitives";

export function Navbar() {
  const pathname = usePathname();
  const { openBookingModal } = useBooking();
  const [scrolled, setScrolled] = useState(false);
  const [drawerPath, setDrawerPath] = useState<string | null>(null);
  const mobileOpen = drawerPath === pathname;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!mobileOpen) return;
    document.body.style.overflow = "hidden";
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setDrawerPath(null);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [mobileOpen]);

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-40 transition-all duration-300 ${
          scrolled
            ? "border-b border-white/10 bg-[#09090b]/80 py-3.5 shadow-[0_12px_40px_-16px_rgba(0,0,0,0.9)] backdrop-blur-2xl"
            : "border-b border-white/[0.06] bg-[#09090b]/45 py-5 backdrop-blur-xl"
        }`}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 sm:px-8">
          {/* Logo */}
          <Link
            href="/"
            className="group inline-flex items-center gap-2.5 focus:outline-none"
          >
            <span className="relative flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/[0.05] text-emerald-400 transition-all duration-300 group-hover:border-emerald-400/40 group-hover:bg-emerald-400/10 group-hover:shadow-[0_0_24px_-4px_rgba(52,211,153,0.5)]">
              <Hexagon className="h-5 w-5 stroke-[1.75]" />
              <span className="absolute h-1.5 w-1.5 rounded-full bg-emerald-400" />
            </span>
            <span className="text-lg font-semibold tracking-tight text-white">
              Quell
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav
            aria-label="Primary Navigation"
            className="hidden items-center gap-1 rounded-full border border-white/[0.08] bg-white/[0.03] px-2 py-1.5 backdrop-blur-xl md:flex"
          >
            {NAV_LINKS.map((item) => {
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`relative rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
                    isActive
                      ? "text-white"
                      : "text-zinc-400 hover:text-zinc-100"
                  }`}
                >
                  {isActive && (
                    <motion.span
                      layoutId="nav-active-pill"
                      transition={{ duration: 0.35, ease: EDITORIAL_EASE }}
                      className="absolute inset-0 rounded-full border border-white/10 bg-white/[0.08]"
                    />
                  )}
                  <span className="relative z-10">{item.label}</span>
                </Link>
              );
            })}
          </nav>

          {/* Desktop Right CTA */}
          <div className="hidden items-center gap-3 md:flex">
            <button
              type="button"
              onClick={() => openBookingModal("AI Automation")}
              className="group inline-flex items-center gap-2 rounded-full border border-emerald-400/35 bg-emerald-400/10 px-5 py-2.5 text-sm font-medium text-emerald-300 shadow-[0_0_28px_-10px_rgba(52,211,153,0.45)] transition-all duration-300 hover:border-emerald-300/70 hover:bg-emerald-400 hover:text-zinc-950"
            >
              <span>Get Free Consultation</span>
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
          </div>

          {/* Mobile Menu Trigger */}
          <button
            type="button"
            onClick={() => setDrawerPath(pathname)}
            aria-label="Open navigation menu"
            className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.05] text-zinc-200 transition-colors hover:border-white/20 hover:bg-white/10 md:hidden"
          >
            <Menu className="h-5 w-5" />
          </button>
        </div>
      </header>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <div className="fixed inset-0 z-50 md:hidden">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              onClick={() => setDrawerPath(null)}
              className="absolute inset-0 bg-black/75 backdrop-blur-sm"
            />
            <motion.aside
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ duration: 0.38, ease: EDITORIAL_EASE }}
              className="absolute inset-y-0 right-0 flex w-[84%] max-w-sm flex-col justify-between border-l border-white/10 bg-[#0b0b0f]/95 p-6 shadow-2xl backdrop-blur-2xl"
            >
              <div>
                <div className="flex items-center justify-between border-b border-white/10 pb-5">
                  <Link
                    href="/"
                    onClick={() => setDrawerPath(null)}
                    className="inline-flex items-center gap-2.5"
                  >
                    <span className="relative flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-emerald-400">
                      <Hexagon className="h-4 w-4 stroke-[1.8]" />
                    </span>
                    <span className="text-base font-semibold tracking-tight text-white">
                      Quell
                    </span>
                  </Link>
                  <button
                    type="button"
                    onClick={() => setDrawerPath(null)}
                    aria-label="Close navigation menu"
                    className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-zinc-300"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>

                <nav className="mt-6 flex flex-col gap-1.5">
                  <Link
                    href="/"
                    onClick={() => setDrawerPath(null)}
                    className={`rounded-xl px-4 py-3 text-base font-medium transition-colors ${
                      pathname === "/"
                        ? "border border-white/10 bg-white/[0.07] text-emerald-300"
                        : "text-zinc-300 hover:bg-white/[0.04] hover:text-white"
                    }`}
                  >
                    Home
                  </Link>
                  {NAV_LINKS.map((item) => {
                    const isActive = pathname === item.href;
                    return (
                      <Link
                        key={item.href}
                        href={item.href}
                        onClick={() => setDrawerPath(null)}
                        className={`flex items-center justify-between rounded-xl px-4 py-3 text-base font-medium transition-colors ${
                          isActive
                            ? "border border-white/10 bg-white/[0.07] text-emerald-300"
                            : "text-zinc-300 hover:bg-white/[0.04] hover:text-white"
                        }`}
                      >
                        <span>{item.label}</span>
                        <ArrowUpRight className="h-4 w-4 opacity-50" />
                      </Link>
                    );
                  })}
                </nav>
              </div>

              <div className="border-t border-white/10 pt-5">
                <p className="mb-3 font-mono text-[11px] uppercase tracking-[0.18em] text-zinc-500">
                  Direct Architecture Call
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setDrawerPath(null);
                    openBookingModal("AI Automation");
                  }}
                  className="flex w-full items-center justify-center gap-2 rounded-full bg-emerald-400 px-5 py-3 text-sm font-semibold text-zinc-950 shadow-[0_0_28px_-8px_rgba(52,211,153,0.65)] transition-colors hover:bg-emerald-300"
                >
                  <span>Get Free Consultation</span>
                  <ArrowUpRight className="h-4 w-4" />
                </button>
              </div>
            </motion.aside>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
