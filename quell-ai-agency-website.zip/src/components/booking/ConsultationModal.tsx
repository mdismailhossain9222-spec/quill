"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";
import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import {
  Calendar,
  CheckCircle2,
  Clock,
  Loader2,
  Sparkles,
  X,
} from "lucide-react";
import { SERVICE_FOCUS_OPTIONS, TIME_SLOTS } from "@/lib/data";
import { EDITORIAL_EASE } from "@/components/motion/MotionPrimitives";

interface BookedSlot {
  date: string;
  time: string;
}

interface BookingReceipt {
  referenceCode: string;
  name: string;
  email: string;
  company: string;
  serviceFocus: string;
  preferredDate: string;
  preferredTime: string;
}

interface ConsultationModalProps {
  isOpen: boolean;
  defaultService?: string;
  onClose: () => void;
}

function getUpcomingBusinessDays(count = 5) {
  const days: { value: string; weekday: string; dayNum: string; month: string }[] = [];
  const cursor = new Date();
  cursor.setDate(cursor.getDate() + 1);

  while (days.length < count) {
    const dow = cursor.getDay();
    if (dow !== 0 && dow !== 6) {
      const iso = cursor.toISOString().split("T")[0];
      days.push({
        value: iso,
        weekday: cursor.toLocaleDateString("en-US", { weekday: "short" }),
        dayNum: cursor.toLocaleDateString("en-US", { day: "2-digit" }),
        month: cursor.toLocaleDateString("en-US", { month: "short" }),
      });
    }
    cursor.setDate(cursor.getDate() + 1);
  }
  return days;
}

export function ConsultationModal({
  isOpen,
  defaultService = "AI Automation",
  onClose,
}: ConsultationModalProps) {
  const upcomingDays = useMemo(() => getUpcomingBusinessDays(5), []);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [preferredDate, setPreferredDate] = useState<string>(
    upcomingDays[0]?.value ?? ""
  );
  const [preferredTime, setPreferredTime] = useState<string>(TIME_SLOTS[1]);
  const [notes, setNotes] = useState("");

  const [bookedSlots, setBookedSlots] = useState<BookedSlot[]>([]);
  const [slotsSynced, setSlotsSynced] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [receipt, setReceipt] = useState<BookingReceipt | null>(null);

  const serviceFocus = selectedService ?? defaultService;
  const loadingSlots = isOpen && !slotsSynced;

  useEffect(() => {
    if (!isOpen) return;

    let cancelled = false;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    document.body.style.overflow = "hidden";

    fetch("/api/consultations")
      .then((res) => (res.ok ? res.json() : { bookedSlots: [] }))
      .then((data: { bookedSlots?: BookedSlot[] }) => {
        if (cancelled) return;
        setBookedSlots(Array.isArray(data.bookedSlots) ? data.bookedSlots : []);
        setSlotsSynced(true);
      })
      .catch(() => {
        if (cancelled) return;
        setBookedSlots([]);
        setSlotsSynced(true);
      });

    return () => {
      cancelled = true;
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "";
    };
  }, [isOpen, onClose]);

  const isSlotBooked = (date: string, time: string) =>
    bookedSlots.some((slot) => slot.date === date && slot.time === time);

  const activeTime = isSlotBooked(preferredDate, preferredTime)
    ? (TIME_SLOTS.find((slot) => !isSlotBooked(preferredDate, slot)) ??
      preferredTime)
    : preferredTime;

  const handleResetAndClose = () => {
    setError(null);
    setReceipt(null);
    setSelectedService(null);
    setSlotsSynced(false);
    onClose();
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      const response = await fetch("/api/consultations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          email,
          company,
          serviceFocus,
          preferredDate,
          preferredTime: activeTime,
          notes,
        }),
      });

      const data = (await response.json()) as {
        error?: string;
        booking?: BookingReceipt;
      };

      if (!response.ok || !data.booking) {
        setError(data.error ?? "Unable to schedule right now.");
        return;
      }

      setReceipt(data.booking);
      setBookedSlots((prev) => [
        ...prev,
        {
          date: data.booking!.preferredDate,
          time: data.booking!.preferredTime,
        },
      ]);
      setName("");
      setEmail("");
      setCompany("");
      setNotes("");
    } catch {
      setError("Network error while booking. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="consultation-modal-title"
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={handleResetAndClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-md"
          />

          {/* Modal container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 18 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 16 }}
            transition={{ duration: 0.35, ease: EDITORIAL_EASE }}
            className="relative z-10 max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-white/15 bg-[#0d0d11]/95 p-6 shadow-[0_32px_100px_-16px_rgba(0,0,0,0.95)] backdrop-blur-2xl sm:p-8"
          >
            {/* Subtle top emerald aura */}
            <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-emerald-400/50 to-transparent" />

            <button
              type="button"
              onClick={handleResetAndClose}
              aria-label="Close booking dialog"
              className="absolute right-5 top-5 flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-zinc-400 transition-colors hover:border-white/20 hover:bg-white/10 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>

            {receipt ? (
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                className="py-4 text-center"
              >
                <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl border border-emerald-400/30 bg-emerald-400/10 text-emerald-400">
                  <CheckCircle2 className="h-7 w-7" />
                </div>
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-emerald-400">
                  Booking Confirmed · {receipt.referenceCode}
                </p>
                <h3 className="mt-2 text-2xl font-medium tracking-tight text-white sm:text-3xl">
                  You&apos;re booked with Mitha.
                </h3>
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-zinc-400">
                  A calendar invite and pre-call workflow brief have been logged
                  for <span className="text-zinc-200">{receipt.email}</span>.
                </p>

                <div className="mx-auto mt-6 max-w-md rounded-2xl border border-white/10 bg-white/[0.04] p-5 text-left">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="font-mono text-[11px] uppercase tracking-wider text-zinc-500">
                        Date &amp; Time
                      </p>
                      <p className="mt-1 font-medium text-white">
                        {receipt.preferredDate}
                      </p>
                      <p className="text-emerald-400">{receipt.preferredTime} PT</p>
                    </div>
                    <div>
                      <p className="font-mono text-[11px] uppercase tracking-wider text-zinc-500">
                        Focus Area
                      </p>
                      <p className="mt-1 font-medium text-white">
                        {receipt.serviceFocus}
                      </p>
                      <p className="text-zinc-400">{receipt.company}</p>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleResetAndClose}
                  className="mt-7 inline-flex items-center justify-center rounded-full bg-white px-6 py-2.5 text-sm font-medium text-zinc-950 transition-colors hover:bg-emerald-300"
                >
                  Return to Quell
                </button>
              </motion.div>
            ) : (
              <div>
                {/* Header */}
                <div className="flex items-center gap-4 pr-10">
                  <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-2xl border border-white/15">
                    <Image
                      src="/images/founder-mitha.png"
                      alt="Mitha, Co-founder of Quell"
                      fill
                      sizes="56px"
                      className="object-cover object-top"
                    />
                    <span className="absolute bottom-1 right-1 h-2.5 w-2.5 rounded-full bg-emerald-400 ring-2 ring-[#0d0d11]" />
                  </div>
                  <div>
                    <div className="inline-flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.18em] text-emerald-400">
                      <Sparkles className="h-3 w-3" />
                      15-Min Discovery Call
                    </div>
                    <h2
                      id="consultation-modal-title"
                      className="mt-0.5 text-xl font-medium tracking-tight text-white sm:text-2xl"
                    >
                      Talk with Mitha, Co-founder
                    </h2>
                  </div>
                </div>

                <p className="mt-4 text-sm leading-relaxed text-zinc-400">
                  Zero sales pitch. We&apos;ll inspect your core operational
                  bottlenecks and outline where deterministic AI systems deliver
                  the highest measurable ROI.
                </p>

                <form onSubmit={handleSubmit} className="mt-6 space-y-5">
                  {/* Focus selector */}
                  <div>
                    <label className="mb-2 block font-mono text-[11px] uppercase tracking-[0.16em] text-zinc-400">
                      Primary Focus
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {SERVICE_FOCUS_OPTIONS.map((option) => {
                        const active = serviceFocus === option;
                        return (
                          <button
                            key={option}
                            type="button"
                            onClick={() => setSelectedService(option)}
                            className={`rounded-full border px-3.5 py-1.5 text-xs font-medium transition-all ${
                              active
                                ? "border-emerald-400/60 bg-emerald-400/15 text-emerald-300"
                                : "border-white/10 bg-white/[0.03] text-zinc-400 hover:border-white/20 hover:text-white"
                            }`}
                          >
                            {option}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Date & Time Row */}
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label className="mb-2 flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.16em] text-zinc-400">
                        <Calendar className="h-3.5 w-3.5 text-emerald-400" />
                        Select Day
                      </label>
                      <div className="grid grid-cols-5 gap-1.5">
                        {upcomingDays.map((day) => {
                          const selected = preferredDate === day.value;
                          return (
                            <button
                              key={day.value}
                              type="button"
                              onClick={() => setPreferredDate(day.value)}
                              className={`flex flex-col items-center rounded-xl border py-2 text-center transition-all ${
                                selected
                                  ? "border-emerald-400/60 bg-emerald-400/15 text-white"
                                  : "border-white/10 bg-white/[0.03] text-zinc-400 hover:border-white/20 hover:text-zinc-200"
                              }`}
                            >
                              <span className="text-[10px] uppercase tracking-wider text-zinc-400">
                                {day.weekday}
                              </span>
                              <span className="mt-0.5 text-sm font-semibold tabular-nums">
                                {day.dayNum}
                              </span>
                              <span className="text-[10px] text-zinc-500">
                                {day.month}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div>
                      <label className="mb-2 flex items-center justify-between font-mono text-[11px] uppercase tracking-[0.16em] text-zinc-400">
                        <span className="inline-flex items-center gap-1.5">
                          <Clock className="h-3.5 w-3.5 text-emerald-400" />
                          Time (PT)
                        </span>
                        {loadingSlots && (
                          <span className="text-[10px] text-zinc-500">
                            Syncing...
                          </span>
                        )}
                      </label>
                      <div className="grid grid-cols-2 gap-1.5">
                        {TIME_SLOTS.map((slot) => {
                          const taken = isSlotBooked(preferredDate, slot);
                          const selected = activeTime === slot && !taken;
                          return (
                            <button
                              key={slot}
                              type="button"
                              disabled={taken}
                              onClick={() => setPreferredTime(slot)}
                              className={`rounded-xl border px-2.5 py-2 text-xs font-medium tabular-nums transition-all ${
                                taken
                                  ? "cursor-not-allowed border-white/5 bg-white/[0.015] text-zinc-600 line-through"
                                  : selected
                                  ? "border-emerald-400/60 bg-emerald-400/15 text-emerald-300"
                                  : "border-white/10 bg-white/[0.03] text-zinc-300 hover:border-white/20 hover:text-white"
                              }`}
                            >
                              {slot}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Contact Inputs */}
                  <div className="grid gap-3.5 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="booking-name"
                        className="mb-1.5 block text-xs font-medium text-zinc-300"
                      >
                        Full Name
                      </label>
                      <input
                        id="booking-name"
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Alex Mercer"
                        className="w-full rounded-xl border border-white/10 bg-white/[0.04] px-3.5 py-2.5 text-sm text-white placeholder-zinc-500 outline-none transition-colors focus:border-emerald-400/60 focus:bg-white/[0.06]"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor="booking-email"
                        className="mb-1.5 block text-xs font-medium text-zinc-300"
                      >
                        Work Email
                      </label>
                      <input
                        id="booking-email"
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="alex@company.com"
                        className="w-full rounded-xl border border-white/10 bg-white/[0.04] px-3.5 py-2.5 text-sm text-white placeholder-zinc-500 outline-none transition-colors focus:border-emerald-400/60 focus:bg-white/[0.06]"
                      />
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="booking-company"
                      className="mb-1.5 block text-xs font-medium text-zinc-300"
                    >
                      Company / Team
                    </label>
                    <input
                      id="booking-company"
                      type="text"
                      required
                      value={company}
                      onChange={(e) => setCompany(e.target.value)}
                      placeholder="Acme Logistics Inc."
                      className="w-full rounded-xl border border-white/10 bg-white/[0.04] px-3.5 py-2.5 text-sm text-white placeholder-zinc-500 outline-none transition-colors focus:border-emerald-400/60 focus:bg-white/[0.06]"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="booking-notes"
                      className="mb-1.5 block text-xs font-medium text-zinc-300"
                    >
                      Workflow context{" "}
                      <span className="text-zinc-500">(optional)</span>
                    </label>
                    <textarea
                      id="booking-notes"
                      rows={2}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Briefly describe the workflow or manual bottleneck you want automated..."
                      className="w-full resize-none rounded-xl border border-white/10 bg-white/[0.04] px-3.5 py-2.5 text-sm text-white placeholder-zinc-500 outline-none transition-colors focus:border-emerald-400/60 focus:bg-white/[0.06]"
                    />
                  </div>

                  {error && (
                    <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-2.5 text-xs text-rose-200">
                      {error}
                    </div>
                  )}

                  <div className="flex flex-col-reverse items-center justify-between gap-3 pt-1 sm:flex-row">
                    <p className="text-xs text-zinc-500">
                      Instant confirmation · Direct Google Meet invite
                    </p>
                    <button
                      type="submit"
                      disabled={submitting}
                      className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-emerald-400 px-6 py-3 text-sm font-semibold text-zinc-950 shadow-[0_0_30px_-6px_rgba(52,211,153,0.6)] transition-all hover:bg-emerald-300 disabled:cursor-not-allowed disabled:opacity-60 sm:w-auto"
                    >
                      {submitting ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Confirming slot...
                        </>
                      ) : (
                        "Confirm 15-min call"
                      )}
                    </button>
                  </div>
                </form>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
