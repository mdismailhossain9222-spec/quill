"use client";

import {
  createContext,
  useCallback,
  useContext,
  useState,
  type ReactNode,
} from "react";
import { ConsultationModal } from "@/components/booking/ConsultationModal";

interface BookingContextValue {
  openBookingModal: (defaultService?: string) => void;
  closeBookingModal: () => void;
}

const BookingContext = createContext<BookingContextValue | undefined>(
  undefined
);

export function BookingProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [defaultService, setDefaultService] = useState("AI Automation");

  const openBookingModal = useCallback((service?: string) => {
    if (service) setDefaultService(service);
    setIsOpen(true);
  }, []);

  const closeBookingModal = useCallback(() => {
    setIsOpen(false);
  }, []);

  return (
    <BookingContext.Provider value={{ openBookingModal, closeBookingModal }}>
      {children}
      <ConsultationModal
        isOpen={isOpen}
        defaultService={defaultService}
        onClose={closeBookingModal}
      />
    </BookingContext.Provider>
  );
}

export function useBooking() {
  const ctx = useContext(BookingContext);
  if (!ctx) {
    throw new Error("useBooking must be used within a BookingProvider");
  }
  return ctx;
}
