"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  ArrowUpRight,
  Bell,
  Calendar,
  CheckCircle2,
  Loader2,
  Sparkles,
} from "lucide-react";
import {
  FadeUp,
  PageTransition,
  StaggerContainer,
  StaggerItem,
} from "@/components/motion/MotionPrimitives";
import { useBooking } from "@/components/providers/BookingContext";

interface ComingSoonPageProps {
  section: "services" | "work" | "about" | "blog" | "contact";
  eyebrow: string;
  headline: string;
  description: string;
  previewNote: string;
}

export function ComingSoonPage({
  section,
  eyebrow,
  headline,
  description,
  previewNote,
}: ComingSoonPageProps) {
  const { openBookingModal } = useBooking();
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleNotify = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setStatusMessage(null);
    setSubmitting(true);

    try {
      const response = await fetch("/api/waitlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, section }),
      });

      const data = (await response.json()) as {
        message?: string;
        error?: string;
      };

      if (!response.ok) {
        setError(data.error ?? "Unable to register right now.");
        return;
      }

      setStatusMessage(
        data.message ?? "You're on the list. We'll notify you at launch."
      );
      setEmail("");
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <PageTransition className="relative flex min-h-[calc(100vh-80px)] flex-col justify-center overflow-hidden bg-[#09090b] pb-24 pt-36 sm:pb-32 sm:pt-44">
      {/* Subtle Architectural Backdrop */}
      <div className="pointer-events-none absolute inset-0 bg-architectural-grid opacity-45" />
      <div className="pointer-events-none absolute left-1/2 top-1/3 h-[500px] w-[720px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-emerald-500/[0.08] blur-[150px]" />

      <div className="relative z-10 mx-auto w-full max-w-4xl px-5 sm:px-8">
        <StaggerContainer immediate className="text-center">
          <StaggerItem>
            <div className="inline-flex items-center gap-2 rounded-full border border-emerald-400/25 bg-emerald-400/10 px-4 py-1.5 font-mono text-[11px] uppercase tracking-[0.22em] text-emerald-400">
              <Sparkles className="h-3 w-3" />
              {eyebrow}
            </div>
          </StaggerItem>

          <StaggerItem>
            <h1 className="mt-6 text-4xl font-medium tracking-[-0.03em] text-white sm:text-6xl">
              {headline}
              <span className="text-emerald-400">.</span>
            </h1>
          </StaggerItem>

          <StaggerItem>
            <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-zinc-400 sm:text-lg">
              {description}
            </p>
          </StaggerItem>
        </StaggerContainer>

        {/* Centerpiece Glass Panel: Coming Soon */}
        <FadeUp immediate delay={0.22} className="mt-12">
          <div className="glass-panel relative overflow-hidden rounded-[2rem] p-8 text-center sm:p-12">
            <div className="pointer-events-none absolute inset-x-12 top-0 h-px bg-gradient-to-r from-transparent via-emerald-400/60 to-transparent" />

            <div className="inline-flex items-center gap-2.5 rounded-full border border-white/10 bg-white/[0.04] px-4 py-1.5 font-mono text-xs uppercase tracking-[0.22em] text-zinc-200">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
              </span>
              In Production
            </div>

            <h2 className="mt-6 text-3xl font-medium tracking-tight text-white sm:text-5xl">
              Coming Soon
            </h2>

            <p className="mx-auto mt-4 max-w-lg text-sm leading-relaxed text-zinc-400 sm:text-base">
              {previewNote}
            </p>

            {/* Launch Notification Form */}
            <form
              onSubmit={handleNotify}
              className="mx-auto mt-8 flex max-w-md flex-col gap-3 sm:flex-row"
            >
              <label htmlFor={`waitlist-${section}`} className="sr-only">
                Work email for launch updates
              </label>
              <input
                id={`waitlist-${section}`}
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@company.com"
                className="flex-1 rounded-full border border-white/15 bg-white/[0.05] px-5 py-3 text-sm text-white placeholder-zinc-500 outline-none transition-colors focus:border-emerald-400/60 focus:bg-white/[0.08]"
              />
              <button
                type="submit"
                disabled={submitting}
                className="inline-flex items-center justify-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-semibold text-zinc-950 transition-colors hover:bg-emerald-300 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {submitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Bell className="h-4 w-4" />
                    Notify me
                  </>
                )}
              </button>
            </form>

            {statusMessage && (
              <div className="mx-auto mt-4 inline-flex items-center gap-2 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-4 py-2 text-xs text-emerald-300">
                <CheckCircle2 className="h-4 w-4 shrink-0" />
                <span>{statusMessage}</span>
              </div>
            )}

            {error && (
              <p className="mt-4 text-xs text-rose-300" role="alert">
                {error}
              </p>
            )}

            {/* Quick Navigation Actions */}
            <div className="mt-10 flex flex-col items-center justify-center gap-3 border-t border-white/10 pt-8 sm:flex-row">
              <button
                type="button"
                onClick={() => openBookingModal("AI Automation")}
                className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-emerald-400 px-6 py-3 text-sm font-semibold text-zinc-950 shadow-[0_0_28px_-8px_rgba(52,211,153,0.6)] transition-colors hover:bg-emerald-300 sm:w-auto"
              >
                <Calendar className="h-4 w-4" />
                <span>Book 15-mins call with Mitha</span>
                <ArrowUpRight className="h-4 w-4" />
              </button>

              <Link
                href="/"
                className="inline-flex w-full items-center justify-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-6 py-3 text-sm font-medium text-zinc-300 transition-colors hover:border-white/25 hover:bg-white/[0.08] hover:text-white sm:w-auto"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Back to Home</span>
              </Link>
            </div>
          </div>
        </FadeUp>
      </div>
    </PageTransition>
  );
}
