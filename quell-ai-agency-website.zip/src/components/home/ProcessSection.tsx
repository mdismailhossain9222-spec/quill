"use client";

import { PROCESS_STEPS } from "@/lib/data";
import { FadeUp } from "@/components/motion/MotionPrimitives";

export function ProcessSection() {
  return (
    <section
      id="process"
      className="relative border-t border-white/[0.08] bg-[#09090b] py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-14 lg:grid-cols-12 lg:gap-12">
          {/* Left Sticky Header */}
          <div className="lg:col-span-4">
            <FadeUp className="lg:sticky lg:top-32">
              <p className="font-mono text-xs uppercase tracking-[0.24em] text-emerald-400">
                Methodology
              </p>
              <h2 className="mt-3 text-3xl font-medium tracking-[-0.025em] text-white sm:text-5xl">
                From audit to autonomous scale.
              </h2>
              <p className="mt-5 text-sm leading-relaxed text-zinc-400 sm:text-base">
                No vague workshops or bloated consulting cycles. Our four-stage
                engineering discipline takes high-impact workflows from
                discovery to hardened production in weeks.
              </p>

              <div className="mt-8 inline-flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-xs text-zinc-300">
                <span className="h-2 w-2 rounded-full bg-emerald-400" />
                <span>Average production rollout: 21–30 days</span>
              </div>
            </FadeUp>
          </div>

          {/* Right 4 Vertical Steps */}
          <div className="relative lg:col-span-8">
            {/* Subtle vertical guide rail */}
            <div className="pointer-events-none absolute bottom-10 left-7 top-10 hidden w-px bg-gradient-to-b from-emerald-400/50 via-white/15 to-transparent sm:block" />

            <div className="space-y-6">
              {PROCESS_STEPS.map((step, index) => (
                <FadeUp key={step.number} delay={index * 0.08}>
                  <div className="glass-panel group relative overflow-hidden rounded-3xl p-6 transition-all duration-300 hover:border-emerald-400/30 sm:p-8 sm:pl-20">
                    {/* Vertical timeline dot on desktop */}
                    <div className="pointer-events-none absolute left-[22px] top-10 hidden h-3 w-3 items-center justify-center rounded-full border border-emerald-400/70 bg-[#09090b] sm:flex">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 transition-transform duration-300 group-hover:scale-125" />
                    </div>

                    <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:gap-8">
                      {/* Large Step Number */}
                      <div className="shrink-0">
                        <span className="font-mono text-5xl font-light tracking-tighter text-white/20 tabular-nums transition-colors duration-300 group-hover:text-emerald-400/80 sm:text-6xl">
                          {step.number}
                        </span>
                      </div>

                      {/* Step Content */}
                      <div className="flex-1">
                        <div className="flex flex-wrap items-baseline justify-between gap-2">
                          <h3 className="text-2xl font-medium tracking-tight text-white sm:text-3xl">
                            {step.title}
                          </h3>
                          <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-emerald-400/90">
                            {step.subtitle}
                          </span>
                        </div>

                        <p className="mt-3 text-sm leading-relaxed text-zinc-400 sm:text-[15px]">
                          {step.description}
                        </p>

                        <div className="mt-5 flex flex-wrap gap-2">
                          {step.deliverables.map((item) => (
                            <span
                              key={item}
                              className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 font-mono text-[11px] text-zinc-300"
                            >
                              {item}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </FadeUp>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
