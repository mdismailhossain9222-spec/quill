"use client";

import { FadeUp } from "@/components/motion/MotionPrimitives";

const CLIENT_LOGOS = [
  {
    name: "VECTRA",
    mark: (
      <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none">
        <path
          d="M4 5L12 19L20 5"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M9 5L12 10.5L15 5"
          stroke="currentColor"
          strokeWidth="1.6"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-emerald-400"
        />
      </svg>
    ),
  },
  {
    name: "NORDLINE",
    mark: (
      <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none">
        <rect
          x="3.5"
          y="4.5"
          width="17"
          height="15"
          rx="2.5"
          stroke="currentColor"
          strokeWidth="1.75"
        />
        <path
          d="M8 15.5V8.5L16 15.5V8.5"
          stroke="currentColor"
          strokeWidth="1.75"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    ),
  },
  {
    name: "AETHERIA",
    mark: (
      <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none">
        <circle cx="12" cy="12" r="8" stroke="currentColor" strokeWidth="1.75" />
        <ellipse
          cx="12"
          cy="12"
          rx="8"
          ry="3.2"
          stroke="currentColor"
          strokeWidth="1.5"
        />
      </svg>
    ),
  },
  {
    name: "KINETIC",
    mark: (
      <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none">
        <path
          d="M5 4V20M19 4L9.5 12L19 20"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    ),
  },
  {
    name: "SOLARIS",
    mark: (
      <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none">
        <polygon
          points="12,3 20,7.5 20,16.5 12,21 4,16.5 4,7.5"
          stroke="currentColor"
          strokeWidth="1.75"
        />
        <circle cx="12" cy="12" r="2.5" fill="currentColor" />
      </svg>
    ),
  },
  {
    name: "HELIX",
    mark: (
      <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none">
        <path
          d="M6 5C14 5 10 19 18 19M18 5C10 5 14 19 6 19"
          stroke="currentColor"
          strokeWidth="1.85"
          strokeLinecap="round"
        />
      </svg>
    ),
  },
];

export function LogoStrip() {
  return (
    <section
      aria-label="Trusted Clients"
      className="relative border-b border-white/[0.08] bg-[#09090b] py-12 sm:py-16"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <FadeUp className="flex flex-col items-center gap-8">
          <p className="font-mono text-[11px] uppercase tracking-[0.26em] text-zinc-500">
            Trusted by teams at
          </p>

          <div className="grid w-full grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {CLIENT_LOGOS.map((client) => (
              <div
                key={client.name}
                className="group flex items-center justify-center gap-2.5 rounded-2xl border border-white/[0.06] bg-white/[0.02] px-4 py-4 text-zinc-500 transition-all duration-300 hover:border-white/15 hover:bg-white/[0.04] hover:text-zinc-100"
              >
                <span className="transition-colors duration-300 group-hover:text-emerald-400">
                  {client.mark}
                </span>
                <span className="font-mono text-xs font-semibold tracking-[0.2em]">
                  {client.name}
                </span>
              </div>
            ))}
          </div>
        </FadeUp>
      </div>
    </section>
  );
}
