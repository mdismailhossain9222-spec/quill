"use client";

import { Quote } from "lucide-react";
import { TESTIMONIALS } from "@/lib/data";
import {
  FadeUp,
  StaggerContainer,
  StaggerItem,
} from "@/components/motion/MotionPrimitives";

export function TestimonialsSection() {
  return (
    <section
      aria-label="Client Testimonials"
      className="relative bg-[#09090b] py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <FadeUp className="max-w-2xl">
          <p className="font-mono text-xs uppercase tracking-[0.24em] text-emerald-400">
            Client Perspectives
          </p>
          <h2 className="mt-3 text-3xl font-medium tracking-[-0.025em] text-white sm:text-5xl">
            Trusted by operators who demand rigor.
          </h2>
        </FadeUp>

        <StaggerContainer className="mt-14 grid gap-6 lg:grid-cols-3">
          {TESTIMONIALS.map((item) => (
            <StaggerItem key={item.name} className="h-full">
              <blockquote className="glass-panel glass-panel-hover flex h-full flex-col justify-between rounded-3xl p-7 sm:p-8">
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-emerald-400/25 bg-emerald-400/10 text-emerald-400">
                      <Quote className="h-4 w-4" />
                    </div>
                    <span className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 font-mono text-[11px] text-emerald-300">
                      {item.impact}
                    </span>
                  </div>

                  <p className="mt-6 text-base leading-relaxed text-zinc-200">
                    &ldquo;{item.quote}&rdquo;
                  </p>
                </div>

                <footer className="mt-8 flex items-center gap-3.5 border-t border-white/[0.08] pt-5">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-white/15 bg-gradient-to-br from-white/10 to-white/[0.02] font-mono text-xs font-semibold text-emerald-300">
                    {item.name
                      .split(" ")
                      .map((part) => part[0])
                      .join("")}
                  </div>
                  <div>
                    <cite className="block not-italic text-sm font-medium text-white">
                      {item.name}
                    </cite>
                    <p className="text-xs text-zinc-400">
                      {item.role}, {item.company}
                    </p>
                  </div>
                </footer>
              </blockquote>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
}
