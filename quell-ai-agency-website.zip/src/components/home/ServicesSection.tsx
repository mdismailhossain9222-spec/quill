"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowUpRight, Bot, Check, Layers, Workflow } from "lucide-react";
import { SERVICES, type ServiceItem } from "@/lib/data";
import {
  EDITORIAL_EASE,
  FadeUp,
  StaggerContainer,
  StaggerItem,
} from "@/components/motion/MotionPrimitives";
import { useBooking } from "@/components/providers/BookingContext";

function ServiceIcon({ name }: { name: ServiceItem["iconName"] }) {
  switch (name) {
    case "workflow":
      return <Workflow className="h-5 w-5" />;
    case "layers":
      return <Layers className="h-5 w-5" />;
    case "bot":
      return <Bot className="h-5 w-5" />;
  }
}

export function ServicesSection() {
  const { openBookingModal } = useBooking();

  return (
    <section
      id="services"
      className="relative overflow-hidden bg-[#09090b] py-24 sm:py-32"
    >
      {/* Subtle architectural emerald glow */}
      <div className="pointer-events-none absolute left-1/2 top-0 h-[420px] w-[720px] -translate-x-1/2 rounded-full bg-emerald-500/[0.05] blur-[140px]" />

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <FadeUp className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <p className="font-mono text-xs uppercase tracking-[0.24em] text-emerald-400">
              Capabilities
            </p>
            <h2 className="mt-3 text-3xl font-medium tracking-[-0.025em] text-white sm:text-5xl">
              Engineered for quiet,
              <span className="block text-zinc-400">
                compounding leverage.
              </span>
            </h2>
          </div>

          <Link
            href="/services"
            className="group inline-flex items-center gap-2 self-start rounded-full border border-white/10 bg-white/[0.04] px-5 py-2.5 text-sm font-medium text-zinc-200 transition-all hover:border-emerald-400/40 hover:bg-emerald-400/10 hover:text-emerald-300 md:self-auto"
          >
            <span>Explore full services</span>
            <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </Link>
        </FadeUp>

        <StaggerContainer className="mt-14 grid gap-6 lg:grid-cols-3">
          {SERVICES.map((service) => (
            <StaggerItem key={service.id} className="h-full">
              <motion.article
                whileHover={{ y: -6, scale: 1.01 }}
                transition={{ duration: 0.35, ease: EDITORIAL_EASE }}
                className="glass-panel glass-panel-hover group relative flex h-full flex-col justify-between overflow-hidden rounded-3xl p-7 sm:p-8"
              >
                {/* Hover emerald edge light */}
                <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-emerald-400/0 to-transparent transition-all duration-500 group-hover:via-emerald-400/60" />
                <div className="pointer-events-none absolute -right-12 -top-12 h-36 w-36 rounded-full bg-emerald-400/0 blur-3xl transition-all duration-500 group-hover:bg-emerald-400/15" />

                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-white/10 bg-white/[0.05] text-emerald-400 transition-all duration-300 group-hover:border-emerald-400/40 group-hover:bg-emerald-400/15 group-hover:shadow-[0_0_24px_-4px_rgba(52,211,153,0.45)]">
                      <ServiceIcon name={service.iconName} />
                    </div>
                    <span className="font-mono text-xs text-zinc-600 transition-colors group-hover:text-emerald-400/80">
                      {service.index}
                    </span>
                  </div>

                  <h3 className="mt-7 text-2xl font-medium tracking-tight text-white">
                    {service.title}
                  </h3>

                  <p className="mt-3 text-sm leading-relaxed text-zinc-400">
                    {service.description}
                  </p>

                  <div className="my-6 h-px w-full bg-white/[0.08]" />

                  <ul className="space-y-3">
                    {service.bullets.map((bullet) => (
                      <li
                        key={bullet}
                        className="flex items-start gap-3 text-sm text-zinc-300"
                      >
                        <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border border-emerald-400/35 bg-emerald-400/10 text-emerald-400">
                          <Check className="h-2.5 w-2.5 stroke-[2.5]" />
                        </span>
                        <span className="leading-snug">{bullet}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-8 pt-2">
                  <button
                    type="button"
                    onClick={() => openBookingModal(service.focusValue)}
                    className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-[0.16em] text-zinc-400 transition-colors group-hover:text-emerald-400"
                  >
                    <span>Scope {service.title}</span>
                    <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </button>
                </div>
              </motion.article>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
}
