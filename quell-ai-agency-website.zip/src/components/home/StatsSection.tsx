"use client";

import { STATS } from "@/lib/data";
import { StaggerContainer, StaggerItem } from "@/components/motion/MotionPrimitives";

export function StatsSection() {
  return (
    <section
      aria-label="Impact Metrics"
      className="relative border-y border-white/[0.08] bg-[#09090b] py-16 sm:py-24"
    >
      <div className="pointer-events-none absolute inset-0 bg-architectural-grid opacity-40" />

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="glass-panel overflow-hidden rounded-3xl">
          <StaggerContainer className="grid grid-cols-1 divide-y divide-white/10 sm:grid-cols-2 sm:divide-y-0 lg:grid-cols-4 lg:divide-x">
            {STATS.map((stat, idx) => (
              <StaggerItem
                key={stat.label}
                className={`p-8 sm:p-10 ${
                  idx < 2 ? "sm:border-b sm:border-white/10 lg:border-b-0" : ""
                } ${idx % 2 === 1 ? "sm:border-l sm:border-white/10" : ""}`}
              >
                <p className="font-mono text-4xl font-semibold tracking-tight text-white tabular-nums sm:text-5xl">
                  <span className="bg-gradient-to-b from-white via-white to-emerald-300 bg-clip-text text-transparent">
                    {stat.value}
                  </span>
                </p>
                <p className="mt-3 text-base font-medium text-zinc-100">
                  {stat.label}
                </p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-500">
                  {stat.sublabel}
                </p>
              </StaggerItem>
            ))}
          </StaggerContainer>
        </div>
      </div>
    </section>
  );
}
