"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, CheckCircle2, Clock, X } from "lucide-react";
import { CASE_STUDIES, type CaseStudyItem } from "@/lib/data";
import {
  EDITORIAL_EASE,
  FadeUp,
  StaggerContainer,
  StaggerItem,
} from "@/components/motion/MotionPrimitives";
import { useBooking } from "@/components/providers/BookingContext";

export function CaseStudiesSection() {
  const { openBookingModal } = useBooking();
  const [activeStudy, setActiveStudy] = useState<CaseStudyItem | null>(null);

  useEffect(() => {
    if (!activeStudy) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setActiveStudy(null);
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [activeStudy]);

  return (
    <section
      id="work"
      className="relative border-t border-white/[0.08] bg-[#09090b] py-24 sm:py-32"
    >
      {/* Ambient emerald spotlight */}
      <div className="pointer-events-none absolute right-0 top-1/3 h-[420px] w-[420px] rounded-full bg-emerald-500/[0.05] blur-[140px]" />

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <FadeUp className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.24em] text-emerald-400">
              Selected Outcomes
            </p>
            <h2 className="mt-3 text-3xl font-medium tracking-[-0.03em] text-white sm:text-5xl">
              Measured, not promised<span className="text-emerald-400">.</span>
            </h2>
          </div>

          <Link
            href="/work"
            className="group inline-flex items-center gap-2 self-start rounded-full border border-white/10 bg-white/[0.04] px-5 py-2.5 text-sm font-medium text-zinc-200 transition-all hover:border-emerald-400/40 hover:bg-emerald-400/10 hover:text-emerald-300 md:self-auto"
          >
            <span>View all case studies</span>
            <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </Link>
        </FadeUp>

        <StaggerContainer className="mt-14 grid gap-6 lg:grid-cols-3">
          {CASE_STUDIES.map((study) => (
            <StaggerItem key={study.id} className="h-full">
              <motion.article
                whileHover={{ y: -6 }}
                transition={{ duration: 0.35, ease: EDITORIAL_EASE }}
                onClick={() => setActiveStudy(study)}
                className="glass-panel glass-panel-hover group flex h-full cursor-pointer flex-col overflow-hidden rounded-3xl"
              >
                {/* Generated 3D Thumbnail */}
                <div className="relative aspect-[16/10] w-full overflow-hidden border-b border-white/10 bg-zinc-950">
                  <Image
                    src={study.image}
                    alt={`${study.title} abstract 3D visualization`}
                    fill
                    sizes="(max-width: 1024px) 100vw, 33vw"
                    className="object-cover object-center transition-transform duration-700 ease-out group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/20 to-transparent" />

                  <div className="absolute left-4 top-4 inline-flex items-center rounded-full border border-white/15 bg-[#09090b]/70 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.16em] text-zinc-200 backdrop-blur-md">
                    {study.industry}
                  </div>
                </div>

                {/* Body */}
                <div className="flex flex-1 flex-col justify-between p-6 sm:p-7">
                  <div>
                    {/* Big Metric */}
                    <div className="flex items-baseline gap-2.5">
                      <span className="text-4xl font-semibold tracking-tight text-emerald-400 tabular-nums sm:text-[2.65rem]">
                        {study.metric}
                      </span>
                      <span className="text-lg font-medium tracking-tight text-white">
                        {study.metricLabel}
                      </span>
                    </div>

                    <h3 className="mt-4 text-lg font-medium tracking-tight text-white transition-colors group-hover:text-emerald-200">
                      {study.title}
                    </h3>

                    <p className="mt-2.5 text-sm leading-relaxed text-zinc-400">
                      {study.description}
                    </p>
                  </div>

                  <div className="mt-6 flex items-center justify-between border-t border-white/[0.08] pt-4 text-xs">
                    <span className="font-mono text-zinc-500">
                      {study.client}
                    </span>
                    <span className="inline-flex items-center gap-1 font-medium text-zinc-300 transition-colors group-hover:text-emerald-400">
                      Inspect brief
                      <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </span>
                  </div>
                </div>
              </motion.article>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>

      {/* Interactive Case Study Brief Modal */}
      <AnimatePresence>
        {activeStudy && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6"
            role="dialog"
            aria-modal="true"
            aria-labelledby="case-study-modal-title"
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveStudy(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 18 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 14 }}
              transition={{ duration: 0.35, ease: EDITORIAL_EASE }}
              className="relative z-10 max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-white/15 bg-[#0d0d11]/95 shadow-2xl backdrop-blur-2xl"
            >
              <button
                type="button"
                onClick={() => setActiveStudy(null)}
                aria-label="Close case study details"
                className="absolute right-4 top-4 z-20 flex h-9 w-9 items-center justify-center rounded-full border border-white/15 bg-black/60 text-zinc-300 backdrop-blur-md transition-colors hover:bg-white/15 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>

              <div className="relative aspect-[16/9] w-full overflow-hidden border-b border-white/10">
                <Image
                  src={activeStudy.image}
                  alt={activeStudy.title}
                  fill
                  sizes="(max-width: 768px) 100vw, 672px"
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d11] via-[#0d0d11]/35 to-transparent" />
                <div className="absolute bottom-5 left-6 right-6">
                  <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-emerald-400">
                    {activeStudy.client} · {activeStudy.industry}
                  </span>
                  <h3
                    id="case-study-modal-title"
                    className="mt-1 text-2xl font-medium tracking-tight text-white"
                  >
                    {activeStudy.title}
                  </h3>
                </div>
              </div>

              <div className="p-6 sm:p-8">
                <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-white/10 bg-white/[0.03] px-5 py-4">
                  <div className="flex items-baseline gap-2.5">
                    <span className="text-3xl font-semibold text-emerald-400 tabular-nums">
                      {activeStudy.metric}
                    </span>
                    <span className="text-base font-medium text-white">
                      {activeStudy.metricLabel}
                    </span>
                  </div>
                  <div className="inline-flex items-center gap-1.5 font-mono text-xs text-zinc-400">
                    <Clock className="h-3.5 w-3.5 text-emerald-400" />
                    {activeStudy.timeline}
                  </div>
                </div>

                <p className="mt-5 text-sm leading-relaxed text-zinc-300">
                  {activeStudy.description}
                </p>

                <div className="mt-6">
                  <h4 className="font-mono text-[11px] uppercase tracking-[0.18em] text-zinc-500">
                    Verified Outcomes
                  </h4>
                  <ul className="mt-3 space-y-2.5">
                    {activeStudy.outcomes.map((item) => (
                      <li
                        key={item}
                        className="flex items-start gap-2.5 text-sm text-zinc-200"
                      >
                        <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-6">
                  <h4 className="font-mono text-[11px] uppercase tracking-[0.18em] text-zinc-500">
                    Production Architecture
                  </h4>
                  <div className="mt-2.5 flex flex-wrap gap-2">
                    {activeStudy.stack.map((tech) => (
                      <span
                        key={tech}
                        className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 font-mono text-xs text-zinc-300"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-8 flex flex-col-reverse gap-3 border-t border-white/10 pt-6 sm:flex-row sm:items-center sm:justify-between">
                  <button
                    type="button"
                    onClick={() => setActiveStudy(null)}
                    className="rounded-full border border-white/10 px-5 py-2.5 text-sm text-zinc-400 transition-colors hover:border-white/20 hover:text-white"
                  >
                    Close brief
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveStudy(null);
                      openBookingModal("AI Automation");
                    }}
                    className="inline-flex items-center justify-center gap-2 rounded-full bg-emerald-400 px-6 py-2.5 text-sm font-semibold text-zinc-950 transition-colors hover:bg-emerald-300"
                  >
                    <span>Build a similar system</span>
                    <ArrowUpRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
