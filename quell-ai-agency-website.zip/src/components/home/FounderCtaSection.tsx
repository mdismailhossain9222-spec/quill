"use client";

import Image from "next/image";
import { ArrowUpRight, Calendar, CheckCircle2 } from "lucide-react";
import { FadeUp } from "@/components/motion/MotionPrimitives";
import { useBooking } from "@/components/providers/BookingContext";

export function FounderCtaSection() {
  const { openBookingModal } = useBooking();

  return (
    <section
      aria-label="Schedule a Call with Mitha"
      className="relative overflow-hidden bg-[#09090b] py-20 pb-28 sm:py-28 sm:pb-36"
    >
      {/* Dramatic subtle emerald radial aura */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-[540px] w-[840px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-emerald-500/[0.09] blur-[150px]" />

      <div className="relative mx-auto max-w-6xl px-5 sm:px-8">
        <FadeUp>
          <div className="glass-panel relative overflow-hidden rounded-[2rem] p-8 sm:p-12 lg:p-16">
            {/* Top emerald hairline shimmer */}
            <div className="pointer-events-none absolute inset-x-10 top-0 h-px bg-gradient-to-r from-transparent via-emerald-400/60 to-transparent" />

            <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-14">
              {/* Prominent Portrait */}
              <div className="flex justify-center lg:col-span-5">
                <div className="relative w-full max-w-[300px] sm:max-w-[340px]">
                  <div className="pointer-events-none absolute -inset-3 rounded-[2rem] bg-gradient-to-tr from-emerald-400/20 via-transparent to-white/10 blur-xl" />
                  <div className="relative aspect-[4/5] w-full overflow-hidden rounded-[1.75rem] border border-white/15 bg-zinc-950 shadow-2xl">
                    <Image
                      src="/images/founder-mitha.png"
                      alt="Mitha, Co-founder of Quell"
                      fill
                      sizes="(max-width: 1024px) 340px, 380px"
                      className="object-cover object-top"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#09090b]/85 via-transparent to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4 rounded-2xl border border-white/15 bg-[#09090b]/75 px-4 py-3 backdrop-blur-xl">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-white">
                            Mitha
                          </p>
                          <p className="font-mono text-[11px] text-zinc-400">
                            Co-founder, Quell
                          </p>
                        </div>
                        <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-1 font-mono text-[10px] text-emerald-300">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                          Available
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Copy & Big CTA */}
              <div className="text-center lg:col-span-7 lg:text-left">
                <p className="font-mono text-xs uppercase tracking-[0.24em] text-emerald-400">
                  Start With Clarity
                </p>
                <h2 className="mt-3 text-4xl font-medium tracking-[-0.03em] text-white sm:text-5xl lg:text-6xl">
                  Talk with Mitha<span className="text-emerald-400">.</span>
                </h2>
                <p className="mx-auto mt-5 max-w-xl text-base leading-relaxed text-zinc-300 lg:mx-0 sm:text-lg">
                  Skip the generic discovery decks. Spend 15 focused minutes
                  with our co-founder to dissect your operational bottlenecks
                  and leave with a concrete AI automation roadmap.
                </p>

                <div className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-zinc-400 lg:justify-start">
                  <span className="inline-flex items-center gap-1.5">
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                    Custom ROI estimate
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                    Direct technical architect
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                    Zero obligation
                  </span>
                </div>

                <div className="mt-9 flex flex-col items-center gap-4 sm:flex-row lg:justify-start sm:justify-center">
                  <button
                    type="button"
                    onClick={() => openBookingModal("Full Systems Audit")}
                    className="group inline-flex w-full items-center justify-center gap-3 rounded-full bg-emerald-400 px-8 py-4 text-base font-semibold text-zinc-950 shadow-[0_14px_44px_-10px_rgba(52,211,153,0.7)] transition-all duration-300 hover:bg-emerald-300 hover:shadow-[0_18px_52px_-8px_rgba(52,211,153,0.85)] active:scale-[0.99] sm:w-auto"
                  >
                    <Calendar className="h-5 w-5" />
                    <span>Book 15-mins call</span>
                    <ArrowUpRight className="h-5 w-5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </button>

                  <a
                    href="mailto:hello@quell.ai"
                    className="inline-flex w-full items-center justify-center rounded-full border border-white/15 bg-white/[0.04] px-7 py-4 text-sm font-medium text-zinc-200 transition-colors hover:border-white/25 hover:bg-white/[0.08] hover:text-white sm:w-auto"
                  >
                    hello@quell.ai
                  </a>
                </div>
              </div>
            </div>
          </div>
        </FadeUp>
      </div>
    </section>
  );
}
