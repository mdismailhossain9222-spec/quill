"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowUpRight, Calendar, Sparkles } from "lucide-react";
import { HERO_CAPABILITIES } from "@/lib/data";
import { useBooking } from "@/components/providers/BookingContext";
import { EDITORIAL_EASE } from "@/components/motion/MotionPrimitives";

const heroStagger = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.08,
    },
  },
};

const heroFadeUp = {
  hidden: { opacity: 0, y: 26 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.75, ease: EDITORIAL_EASE },
  },
};

export function HeroSection() {
  const { openBookingModal } = useBooking();

  return (
    <section className="relative flex min-h-screen w-full flex-col justify-between overflow-hidden bg-[#09090b] pt-28 pb-10 sm:pt-32 sm:pb-14">
      {/* Full-cover AI-generated 3D cinematic background */}
      <div className="pointer-events-none absolute inset-0 z-0">
        <Image
          src="/images/hero-bg.png"
          alt="Abstract obsidian and emerald 3D glass sculpture"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center opacity-85 scale-[1.02]"
        />
        {/* Layered dark editorial vignette for crisp legibility */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#09090b]/85 via-[#09090b]/45 to-[#09090b]" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#09090b]/92 via-[#09090b]/50 to-[#09090b]/35" />
        {/* Subtle emerald ambient focal light */}
        <div className="absolute -right-24 top-1/4 h-[480px] w-[480px] rounded-full bg-emerald-500/10 blur-[130px]" />
      </div>

      {/* Main Content Wrapper */}
      <motion.div
        variants={heroStagger}
        initial="hidden"
        animate="visible"
        className="relative z-10 mx-auto flex w-full max-w-7xl flex-1 flex-col justify-between gap-16 px-5 sm:px-8"
      >
        {/* TOP ROW: Capabilities List + Editorial Intro */}
        <div className="flex flex-col justify-between gap-8 pt-4 md:flex-row md:items-start">
          <motion.ul
            variants={heroFadeUp}
            className="space-y-2.5 border-l border-white/15 pl-4"
          >
            {HERO_CAPABILITIES.map((capability, idx) => (
              <li
                key={capability}
                className="flex items-center gap-3 font-mono text-xs tracking-[0.22em] text-zinc-300"
              >
                <span className="text-[10px] text-emerald-400">
                  0{idx + 1}
                </span>
                <span>{capability}</span>
              </li>
            ))}
          </motion.ul>

          <motion.div
            variants={heroFadeUp}
            className="max-w-sm md:text-right"
          >
            <p className="text-sm leading-relaxed text-zinc-300/90 sm:text-[15px]">
              We engineer deterministic AI workflows, deep enterprise
              integrations, and autonomous agents that turn complex operations
              into quiet, measurable leverage.
            </p>
          </motion.div>
        </div>

        {/* BOTTOM ROW: Big Headline + Glass Badge | Founder Glass Contact Card */}
        <div className="grid items-end gap-10 lg:grid-cols-12 lg:gap-8">
          {/* Left: Badge + Monumental Headline */}
          <div className="lg:col-span-7 xl:col-span-8">
            <motion.div variants={heroFadeUp} className="mb-6">
              <div className="inline-flex items-center gap-2.5 rounded-full border border-white/15 bg-white/[0.06] px-4 py-2 text-xs font-medium text-zinc-100 shadow-[0_8px_32px_-8px_rgba(0,0,0,0.8)] backdrop-blur-xl">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
                </span>
                <span>We Automate 100+ Businesses</span>
                <Sparkles className="h-3.5 w-3.5 text-emerald-400" />
              </div>
            </motion.div>

            <motion.h1
              variants={heroFadeUp}
              className="text-5xl font-medium leading-[1.02] tracking-[-0.035em] text-white sm:text-6xl md:text-7xl xl:text-[5.25rem]"
            >
              Clear<span className="text-emerald-400">.</span>
              <br />
              Precise<span className="text-emerald-400">.</span>
              <br />
              <span className="bg-gradient-to-r from-white via-zinc-100 to-emerald-300 bg-clip-text text-transparent">
                Automated
              </span>
              <span className="text-emerald-400">.</span>
            </motion.h1>
          </div>

          {/* Right: Glass Founder Contact Card */}
          <motion.div
            variants={heroFadeUp}
            className="lg:col-span-5 xl:col-span-4"
          >
            <div className="glass-panel group relative overflow-hidden rounded-3xl p-6 transition-all duration-500 hover:border-emerald-400/35">
              {/* Top subtle reflective highlight */}
              <div className="pointer-events-none absolute inset-x-6 top-0 h-px bg-gradient-to-r from-transparent via-emerald-400/40 to-transparent" />

              <div className="flex items-center gap-4">
                <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-2xl border border-white/15 shadow-lg">
                  <Image
                    src="/images/founder-mitha.png"
                    alt="Mitha, Co-founder at Quell"
                    fill
                    priority
                    sizes="64px"
                    className="object-cover object-top transition-transform duration-500 group-hover:scale-105"
                  />
                  <span
                    title="Available for calls"
                    className="absolute bottom-1.5 right-1.5 h-2.5 w-2.5 rounded-full bg-emerald-400 ring-2 ring-[#0d0d10]"
                  />
                </div>
                <div className="min-w-0">
                  <span className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.18em] text-emerald-400">
                    Direct Founder Access
                  </span>
                  <h2 className="mt-0.5 text-base font-medium text-white">
                    Talk with Mitha, Co-founder
                  </h2>
                  <p className="mt-0.5 text-xs text-zinc-400">
                    Architecture audit · Zero fluff
                  </p>
                </div>
              </div>

              <p className="mt-4 text-xs leading-relaxed text-zinc-400">
                Bring your slowest operational workflow. We&apos;ll map an
                automation blueprint and clear ROI timeline in 15 minutes.
              </p>

              <button
                type="button"
                onClick={() => openBookingModal("AI Automation")}
                className="mt-5 flex w-full items-center justify-between rounded-2xl bg-emerald-400 px-5 py-3.5 text-sm font-semibold text-zinc-950 shadow-[0_10px_34px_-8px_rgba(52,211,153,0.65)] transition-all duration-300 hover:bg-emerald-300 active:scale-[0.99]"
              >
                <span className="inline-flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Book 15-mins call
                </span>
                <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </button>
            </div>
          </motion.div>
        </div>
      </motion.div>

      {/* Bottom architectural hairline */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
    </section>
  );
}
